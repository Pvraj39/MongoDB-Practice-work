package com.elearning.dao;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.elearning.config.MongoDBConnection;
import com.elearning.model.Instructor;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import static com.mongodb.client.model.Filters.eq;

public class InstructorDAO {

    private MongoCollection<Document> collection;

    public InstructorDAO() {

        MongoDatabase database =
                MongoDBConnection.getDatabase();

        collection =
                database.getCollection("instructors");
    }

    // CREATE
    public void addInstructor(Instructor instructor) {

        Document document =
                new Document("instructorId",
                        instructor.getInstructorId())
                .append("name",
                        instructor.getName())
                .append("email",
                        instructor.getEmail())
                .append("specialization",
                        instructor.getSpecialization());

        collection.insertOne(document);
    }

    // READ ALL
    public List<Document> getAllInstructors() {

        List<Document> instructors =
                new ArrayList<>();

        collection.find().into(instructors);

        return instructors;
    }

    // READ BY ID
    public Document getInstructorById(
            String instructorId) {

        return collection.find(
                eq("instructorId",
                        instructorId))
                .first();
    }

    // UPDATE
    public void updateInstructorEmail(
            String instructorId,
            String email) {

        collection.updateOne(
                eq("instructorId",
                        instructorId),
                new Document(
                        "$set",
                        new Document(
                                "email",
                                email))
        );
    }

    // DELETE
    public void deleteInstructor(
            String instructorId) {

        collection.deleteOne(
                eq("instructorId",
                        instructorId));
    }
}