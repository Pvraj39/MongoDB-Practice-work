package com.elearning.dao;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.elearning.config.MongoDBConnection;
import com.elearning.model.Course;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.regex;

import static com.mongodb.client.model.Aggregates.*;
import static com.mongodb.client.model.Accumulators.*;


public class CourseDAO {

    private MongoCollection<Document> collection;

    public CourseDAO() {

        MongoDatabase database =
                MongoDBConnection.getDatabase();

        collection =
                database.getCollection("courses");
    }

    // CREATE
    public void addCourse(Course course) {

        Document document =
                new Document("courseId",
                        course.getCourseId())
                .append("courseName",
                        course.getCourseName())
                .append("description",
                        course.getDescription())
                .append("duration",
                        course.getDuration())
                .append("instructorId",
                        course.getInstructorId());

        collection.insertOne(document);
    }

    // READ ALL
    public List<Document> getAllCourses() {

        List<Document> courses =
                new ArrayList<>();

        collection.find().into(courses);

        return courses;
    }

    // READ BY ID
    public Document getCourseById(String courseId) {

        return collection.find(
                eq("courseId", courseId))
                .first();
    }

    // UPDATE
    public void updateCourseName(
            String courseId,
            String courseName) {

        collection.updateOne(
                eq("courseId", courseId),
                new Document(
                        "$set",
                        new Document(
                                "courseName",
                                courseName))
        );
    }

    // DELETE
    public void deleteCourse(
            String courseId) {

        collection.deleteOne(
                eq("courseId", courseId));
    }

     //Course Search API
     public List<Document> searchCoursesByName(
        String courseName) {

    List<Document> courses =
            new ArrayList<>();

    collection.find(
            regex(
                    "courseName",
                    courseName,
                    "i"))
            .into(courses);

    return courses;
}

  //course tracker 
    public List<Document> getCourseCompletionReport() {

    MongoDatabase database =
            MongoDBConnection.getDatabase();

    MongoCollection<Document> enrollments =
            database.getCollection("enrollments");

    List<Document> report =
            new ArrayList<>();

    enrollments.aggregate(
            java.util.Arrays.asList(

                    group(
                            "$courseId",
                            avg(
                                    "averageCompletion",
                                    "$progress")
                    ),

                    lookup(
                            "courses",
                            "_id",
                            "courseId",
                            "courseInfo"
                    )
            ))
            .into(report);

    return report;
}
}