package com.elearning.dao;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.elearning.config.MongoDBConnection;
import com.elearning.model.Lesson;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import static com.mongodb.client.model.Filters.eq;

public class LessonDAO {

    private MongoCollection<Document> collection;

    public LessonDAO() {

        MongoDatabase database =
                MongoDBConnection.getDatabase();

        collection =
                database.getCollection("lessons");
    }

    // CREATE
    public void addLesson(Lesson lesson) {

        Document document =
                new Document("lessonId",
                        lesson.getLessonId())
                .append("courseId",
                        lesson.getCourseId())
                .append("title",
                        lesson.getTitle())
                .append("videoUrl",
                        lesson.getVideoUrl());

        collection.insertOne(document);
    }

    // READ ALL
    public List<Document> getAllLessons() {

        List<Document> lessons =
                new ArrayList<>();

        collection.find().into(lessons);

        return lessons;
    }

    // READ BY ID
    public Document getLessonById(String lessonId) {

        return collection.find(
                eq("lessonId", lessonId))
                .first();
    }

    // UPDATE
    public void updateLessonTitle(
            String lessonId,
            String title) {

        collection.updateOne(
                eq("lessonId", lessonId),
                new Document(
                        "$set",
                        new Document(
                                "title",
                                title))
        );
    }

    // DELETE
    public void deleteLesson(
            String lessonId) {

        collection.deleteOne(
                eq("lessonId", lessonId));
    }
}