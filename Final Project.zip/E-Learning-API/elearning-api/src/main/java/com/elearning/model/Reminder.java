package com.elearning.model;

public class Reminder {

    private String reminderId;
    private String studentId;
    private String courseId;
    private String message;
    private String reminderDate;
    private String status;

    public Reminder() {
    }

    public Reminder(String reminderId,
                    String studentId,
                    String courseId,
                    String message,
                    String reminderDate,
                    String status) {

        this.reminderId = reminderId;
        this.studentId = studentId;
        this.courseId = courseId;
        this.message = message;
        this.reminderDate = reminderDate;
        this.status = status;
    }

    public String getReminderId() {
        return reminderId;
    }

    public void setReminderId(String reminderId) {
        this.reminderId = reminderId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getReminderDate() {
        return reminderDate;
    }

    public void setReminderDate(String reminderDate) {
        this.reminderDate = reminderDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}