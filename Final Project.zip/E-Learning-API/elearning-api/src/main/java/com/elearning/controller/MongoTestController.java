package com.elearning.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elearning.config.MongoDBConnection;
import com.mongodb.client.MongoDatabase;

@RestController
public class MongoTestController {

    @GetMapping("/mongo-test")
    public String testMongo() {

        MongoDatabase db =
                MongoDBConnection.getDatabase();

        return "Connected to Database: "
                + db.getName();
    }
}