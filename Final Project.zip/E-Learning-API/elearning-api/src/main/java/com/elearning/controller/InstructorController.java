package com.elearning.controller;

import java.util.List;

import org.bson.Document;
import org.springframework.web.bind.annotation.*;

import com.elearning.dao.InstructorDAO;
import com.elearning.model.Instructor;

@RestController
@RequestMapping("/instructors")
public class InstructorController {

    private final InstructorDAO dao =
            new InstructorDAO();

    // CREATE
    @PostMapping
    public String addInstructor(
            @RequestBody Instructor instructor) {

        dao.addInstructor(instructor);

        return "Instructor Added Successfully";
    }

    // READ ALL
    @GetMapping
    public List<Document> getAllInstructors() {

        return dao.getAllInstructors();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public Document getInstructorById(
            @PathVariable String id) {

        return dao.getInstructorById(id);
    }

    // UPDATE
    @PutMapping("/{id}")
    public String updateInstructor(
            @PathVariable String id,
            @RequestBody Instructor instructor) {

        dao.updateInstructorEmail(
                id,
                instructor.getEmail());

        return "Instructor Updated Successfully";
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteInstructor(
            @PathVariable String id) {

        dao.deleteInstructor(id);

        return "Instructor Deleted Successfully";
    }
}