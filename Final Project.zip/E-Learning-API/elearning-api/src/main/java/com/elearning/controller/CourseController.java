package com.elearning.controller;

import java.util.List;

import org.bson.Document;
import org.springframework.web.bind.annotation.*;

import com.elearning.dao.CourseDAO;
import com.elearning.model.Course;

@RestController
@RequestMapping("/courses")
public class CourseController {

    private final CourseDAO dao =
            new CourseDAO();

    // CREATE
    @PostMapping
    public String addCourse(
            @RequestBody Course course) {

        dao.addCourse(course);

        return "Course Added Successfully";
    }

    // READ ALL
    @GetMapping
    public List<Document> getAllCourses() {

        return dao.getAllCourses();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public Document getCourseById(
            @PathVariable String id) {

        return dao.getCourseById(id);
    }

    // UPDATE
    @PutMapping("/{id}")
    public String updateCourse(
            @PathVariable String id,
            @RequestBody Course course) {

        dao.updateCourseName(
                id,
                course.getCourseName());

        return "Course Updated Successfully";
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteCourse(
            @PathVariable String id) {

        dao.deleteCourse(id);

        return "Course Deleted Successfully";
    }

    //search
    @GetMapping("/search/{name}")
    public List<Document> searchCourses(
        @PathVariable String name) {

    return dao.searchCoursesByName(name);
}

  // course tracker
  @GetMapping("/completion-report")
public List<Document> getCompletionReport() {

    return dao.getCourseCompletionReport();
}
}