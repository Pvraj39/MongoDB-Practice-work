package com.elearning.controller;

import java.util.List;

import org.bson.Document;
import org.springframework.web.bind.annotation.*;

import com.elearning.dao.LessonDAO;
import com.elearning.model.Lesson;

@RestController
@RequestMapping("/lessons")
public class LessonController {

    private final LessonDAO dao =
            new LessonDAO();

    // CREATE
    @PostMapping
    public String addLesson(
            @RequestBody Lesson lesson) {

        dao.addLesson(lesson);

        return "Lesson Added Successfully";
    }

    // READ ALL
    @GetMapping
    public List<Document> getAllLessons() {

        return dao.getAllLessons();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public Document getLessonById(
            @PathVariable String id) {

        return dao.getLessonById(id);
    }

    // UPDATE
    @PutMapping("/{id}")
    public String updateLesson(
            @PathVariable String id,
            @RequestBody Lesson lesson) {

        dao.updateLessonTitle(
                id,
                lesson.getTitle());

        return "Lesson Updated Successfully";
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteLesson(
            @PathVariable String id) {

        dao.deleteLesson(id);

        return "Lesson Deleted Successfully";
    }
}