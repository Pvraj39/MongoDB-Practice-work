package com.elearning.controller;

import java.util.List;

import org.bson.Document;
import org.springframework.web.bind.annotation.*;

import com.elearning.dao.StudentDAO;
import com.elearning.model.Student;

@RestController
@RequestMapping("/students")
public class StudentController {

    private final StudentDAO dao = new StudentDAO();

    // CREATE
    @PostMapping
    public String addStudent(@RequestBody Student student) {

        dao.addStudent(student);
        return "Student Added Successfully";
    }

    // READ ALL
    @GetMapping
    public List<Document> getAllStudents() {

        return dao.getAllStudents();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public Document getStudentById(
            @PathVariable String id) {

        return dao.getStudentById(id);
    }

    // UPDATE
    @PutMapping("/{id}")
    public String updateStudent(
            @PathVariable String id,
            @RequestBody Student student) {

        dao.updateStudentEmail(
                id,
                student.getEmail());

        return "Student Updated Successfully";
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteStudent(
            @PathVariable String id) {

        dao.deleteStudent(id);

        return "Student Deleted Successfully";
    }
}