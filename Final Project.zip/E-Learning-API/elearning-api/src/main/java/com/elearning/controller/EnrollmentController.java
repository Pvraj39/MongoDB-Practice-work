package com.elearning.controller;

import java.util.List;

import org.bson.Document;
import org.springframework.web.bind.annotation.*;

import com.elearning.dao.EnrollmentDAO;
import com.elearning.model.Enrollment;

@RestController
@RequestMapping("/enrollments")
public class EnrollmentController {

    private final EnrollmentDAO dao =
            new EnrollmentDAO();

    // CREATE
    @PostMapping
    public String enrollStudent(
            @RequestBody Enrollment enrollment) {

        dao.enrollStudent(enrollment);

        return "Student Enrolled Successfully";
    }

    // READ ALL
    @GetMapping
    public List<Document> getAllEnrollments() {

        return dao.getAllEnrollments();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public Document getEnrollmentById(
            @PathVariable String id) {

        return dao.getEnrollmentById(id);
    }

    // UPDATE PROGRESS
    @PutMapping("/{id}")
    public String updateProgress(
            @PathVariable String id,
            @RequestBody Enrollment enrollment) {

        dao.updateProgress(
                id,
                enrollment.getProgress());

        return "Progress Updated Successfully";
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteEnrollment(
            @PathVariable String id) {

        dao.deleteEnrollment(id);

        return "Enrollment Deleted Successfully";
    }

    // dashboard
    @GetMapping("/dashboard/{studentId}")
    public List<Document> getDashboard(
        @PathVariable String studentId) {

    return dao.getStudentDashboard(studentId);
}

   //statistics
   @GetMapping("/statistics")
public List<Document> courseStatistics() {

    return dao.courseStatistics();
}
}