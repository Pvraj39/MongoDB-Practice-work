package com.elearning.model;

public class Lesson {

    private String lessonId;
    private String courseId;
    private String title;
    private String videoUrl;

    public Lesson() {
    }

    public Lesson(String lessonId,
                  String courseId,
                  String title,
                  String videoUrl) {

        this.lessonId = lessonId;
        this.courseId = courseId;
        this.title = title;
        this.videoUrl = videoUrl;
    }

    public String getLessonId() {
        return lessonId;
    }

    public void setLessonId(String lessonId) {
        this.lessonId = lessonId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}