package com.elearning.controller;

import java.util.List;

import org.bson.Document;
import org.springframework.web.bind.annotation.*;

import com.elearning.dao.ReminderDAO;
import com.elearning.model.Reminder;

@RestController
@RequestMapping("/reminders")
public class ReminderController {

    private final ReminderDAO dao =
            new ReminderDAO();

    @PostMapping
    public String addReminder(
            @RequestBody Reminder reminder) {

        dao.addReminder(reminder);

        return "Reminder Added Successfully";
    }

    @GetMapping
    public List<Document> getAllReminders() {

        return dao.getAllReminders();
    }

    @GetMapping("/student/{studentId}")
    public List<Document> getRemindersByStudent(
            @PathVariable String studentId) {

        return dao.getRemindersByStudent(studentId);
    }

    @PutMapping("/{id}")
    public String updateStatus(
            @PathVariable String id,
            @RequestBody Reminder reminder) {

        dao.updateStatus(
                id,
                reminder.getStatus());

        return "Reminder Updated Successfully";
    }

    @DeleteMapping("/{id}")
    public String deleteReminder(
            @PathVariable String id) {

        dao.deleteReminder(id);

        return "Reminder Deleted Successfully";
    }
}