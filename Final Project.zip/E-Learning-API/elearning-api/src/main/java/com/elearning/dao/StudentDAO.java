package com.elearning.dao;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.elearning.config.MongoDBConnection;
import com.elearning.model.Student;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import static com.mongodb.client.model.Filters.eq;

public class StudentDAO {

    private MongoCollection<Document> collection;

    public StudentDAO() {

        MongoDatabase database =
                MongoDBConnection.getDatabase();

        collection =
                database.getCollection("students");
    }

    // CREATE
    public void addStudent(Student student) {

        Document document =
                new Document("studentId",
                        student.getStudentId())
                .append("name",
                        student.getName())
                .append("email",
                        student.getEmail())
                .append("phone",
                        student.getPhone());

        collection.insertOne(document);
    }

    // READ ALL
    public List<Document> getAllStudents() {

        List<Document> students =
                new ArrayList<>();

        collection.find().into(students);

        return students;
    }

    // READ BY ID
    public Document getStudentById(String studentId) {

        return collection.find(
                eq("studentId", studentId))
                .first();
    }

    // UPDATE
    public void updateStudentEmail(
            String studentId,
            String email) {

        collection.updateOne(
                eq("studentId", studentId),
                new Document(
                        "$set",
                        new Document(
                                "email",
                                email))
        );
    }

    // DELETE
    public void deleteStudent(
            String studentId) {

        collection.deleteOne(
                eq("studentId", studentId));
    }
}