package com.elearning.dao;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.elearning.config.MongoDBConnection;
import com.elearning.model.Reminder;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import static com.mongodb.client.model.Filters.eq;

public class ReminderDAO {

    private MongoCollection<Document> collection;

    public ReminderDAO() {

        MongoDatabase database =
                MongoDBConnection.getDatabase();

        collection =
                database.getCollection("reminders");
    }

    // CREATE
    public void addReminder(Reminder reminder) {

        Document document =
                new Document("reminderId",
                        reminder.getReminderId())
                .append("studentId",
                        reminder.getStudentId())
                .append("courseId",
                        reminder.getCourseId())
                .append("message",
                        reminder.getMessage())
                .append("reminderDate",
                        reminder.getReminderDate())
                .append("status",
                        reminder.getStatus());

        collection.insertOne(document);
    }

    // READ ALL
    public List<Document> getAllReminders() {

        List<Document> reminders =
                new ArrayList<>();

        collection.find().into(reminders);

        return reminders;
    }

    // READ BY STUDENT
    public List<Document> getRemindersByStudent(
            String studentId) {

        List<Document> reminders =
                new ArrayList<>();

        collection.find(
                eq("studentId",
                        studentId))
                .into(reminders);

        return reminders;
    }

    // UPDATE STATUS
    public void updateStatus(
            String reminderId,
            String status) {

        collection.updateOne(
                eq("reminderId",
                        reminderId),
                new Document(
                        "$set",
                        new Document(
                                "status",
                                status))
        );
    }

    // DELETE
    public void deleteReminder(
            String reminderId) {

        collection.deleteOne(
                eq("reminderId",
                        reminderId));
    }
}
