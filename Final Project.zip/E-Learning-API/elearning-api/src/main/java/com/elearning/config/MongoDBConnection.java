package com.elearning.config;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class MongoDBConnection {

    private static final String URL =
            "mongodb://localhost:27017";

    private static MongoClient client =
            MongoClients.create(URL);

    public static MongoDatabase getDatabase() {

        return client.getDatabase("ElearningDB");
    }
}