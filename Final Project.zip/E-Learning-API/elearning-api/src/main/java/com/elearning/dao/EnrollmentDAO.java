package com.elearning.dao;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.elearning.config.MongoDBConnection;
import com.elearning.model.Enrollment;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import static com.mongodb.client.model.Filters.eq;

import static com.mongodb.client.model.Aggregates.*;
import static com.mongodb.client.model.Filters.*;
import static com.mongodb.client.model.Accumulators.sum;

public class EnrollmentDAO {

    private MongoCollection<Document> collection;

    public EnrollmentDAO() {

        MongoDatabase database =
                MongoDBConnection.getDatabase();

        collection =
                database.getCollection("enrollments");
    }

    // CREATE
    public void enrollStudent(Enrollment enrollment) {

        Document document =
                new Document("enrollmentId",
                        enrollment.getEnrollmentId())
                .append("studentId",
                        enrollment.getStudentId())
                .append("courseId",
                        enrollment.getCourseId())
                .append("progress",
                        enrollment.getProgress());

        collection.insertOne(document);
    }

    // READ ALL
    public List<Document> getAllEnrollments() {

        List<Document> enrollments =
                new ArrayList<>();

        collection.find().into(enrollments);

        return enrollments;
    }

    // READ BY ID
    public Document getEnrollmentById(
            String enrollmentId) {

        return collection.find(
                eq("enrollmentId",
                        enrollmentId))
                .first();
    }

    // UPDATE PROGRESS
    public void updateProgress(
            String enrollmentId,
            int progress) {

        collection.updateOne(
                eq("enrollmentId",
                        enrollmentId),
                new Document(
                        "$set",
                        new Document(
                                "progress",
                                progress))
        );
    }

    // DELETE
    public void deleteEnrollment(
            String enrollmentId) {

        collection.deleteOne(
                eq("enrollmentId",
                        enrollmentId));
    }

        // Get Enrollments by Student ID
       public List<Document> getStudentDashboard(
        String studentId) {

    List<Document> dashboard =
            new ArrayList<>();

    collection.aggregate(
            java.util.Arrays.asList(

                    match(
                            eq("studentId",
                                    studentId)),

                    lookup(
                            "courses",
                            "courseId",
                            "courseId",
                            "courseDetails")
            ))
            .into(dashboard);

    return dashboard;
}

   //Statistics
      public List<Document> courseStatistics() {

    List<Document> statistics =
            new ArrayList<>();

    collection.aggregate(
            java.util.Arrays.asList(
                    group(
                            "$courseId",
                            sum(
                                    "totalStudents",
                                    1))
            ))
            .into(statistics);

    return statistics;
}
}